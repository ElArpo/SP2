#ifndef FUNCTIONS_H
#define FUNCTIONS_H

int getEKGADC();
void measureAndSend();


#endif