#include <Arduino.h>
#include "functions.h"
#include <SPI.h>

int getEKGADC() {
  digitalWrite(10, LOW);
  int value = SPI.transfer16(0x00);
  digitalWrite(10, HIGH);
  return value;
}

void measureAndSend(){
Serial.println(getEKGADC());  
}

